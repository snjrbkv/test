var cardInfos = document.querySelectorAll(".card--info");
var plusIcons = document.querySelectorAll('.icon-plus');



function truncateWords(text, numWords) {
    var words = text.split(/\s+/);
    words = words.filter(function (word) {
        return word.trim().length > 0;
    });

    if (numWords >= words.length) {
        return text;
    }
    return words.slice(0, numWords).join(' ') + ' ...';
}


plusIcons.forEach(function (icon) {
    icon.addEventListener('click', function () {
        var infoElement = this.previousElementSibling;
        if (infoElement && infoElement.classList.contains('card--info')) {
            var infoOpen = infoElement.getAttribute('open');
            if (infoOpen == 'on') {
                infoText = infoElement.getAttribute('data-text');
                infoElement.innerText = truncateWords(infoText, 15).trim();
                icon.style.transition = '300ms';
                icon.classList.toggle('icon-plus-animate');
                infoElement.setAttribute('open', 'off');
            } else {
                infoText = infoElement.getAttribute('data-text');
                infoElement.innerText = infoText;
                icon.style.transition = '300ms';
                icon.classList.toggle('icon-plus-animate');
                infoElement.setAttribute('open', 'on');
            }
        }
    });
});

cardInfos.forEach((cardInfo) => {
    console.log(cardInfo);
    infoText = cardInfo.getAttribute('data-text').trim();
    cardInfo.innerText = truncateWords(infoText, 15).trim();
})